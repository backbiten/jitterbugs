"""
tests/test_intelligence.py
==========================
Unit tests for the Meta IA Intelligence Engine.
"""

import pytest
import numpy as np
from meta_ia.core.intelligence import (
    IntelligenceEngine,
    _tokenize,
    _build_vocab,
    _tfidf_matrix,
    _cosine_similarity,
)
from meta_ia.utils.config import Config


# ---------------------------------------------------------------------------
# Helper / unit tests
# ---------------------------------------------------------------------------

class TestTokenize:
    def test_basic(self):
        assert _tokenize("Hello, World!") == ["hello", "world"]

    def test_removes_punctuation(self):
        assert "." not in _tokenize("sentence.")
        assert "," not in _tokenize("one, two")

    def test_empty(self):
        assert _tokenize("") == []

    def test_numbers(self):
        tokens = _tokenize("model v2 with 3 layers")
        assert "v2" in tokens
        # Single-char tokens like '3' are filtered (len > 1 rule)
        assert "model" in tokens


class TestVocab:
    def test_builds_correctly(self):
        vocab = _build_vocab(["hello world", "world of python"])
        assert "hello" in vocab
        assert "world" in vocab
        assert "python" in vocab

    def test_unique_indices(self):
        vocab = _build_vocab(["apple banana cherry"])
        assert len(set(vocab.values())) == len(vocab)


class TestTFIDF:
    def test_shape(self):
        corpus = ["quick brown fox", "lazy dog", "quick lazy"]
        vocab  = _build_vocab(corpus)
        matrix = _tfidf_matrix(corpus, vocab)
        assert matrix.shape == (3, len(vocab))

    def test_dtype(self):
        corpus = ["hello world"]
        vocab  = _build_vocab(corpus)
        matrix = _tfidf_matrix(corpus, vocab)
        assert matrix.dtype == np.float64

    def test_non_negative(self):
        corpus = ["alpha beta gamma", "beta gamma delta"]
        vocab  = _build_vocab(corpus)
        matrix = _tfidf_matrix(corpus, vocab)
        assert np.all(matrix >= 0)


class TestCosineSimilarity:
    def test_identical_vectors(self):
        v = np.array([1.0, 2.0, 3.0])
        assert abs(_cosine_similarity(v, v) - 1.0) < 1e-6

    def test_orthogonal_vectors(self):
        a = np.array([1.0, 0.0])
        b = np.array([0.0, 1.0])
        assert abs(_cosine_similarity(a, b)) < 1e-6

    def test_zero_vector(self):
        v = np.array([1.0, 2.0])
        z = np.zeros(2)
        assert _cosine_similarity(v, z) == 0.0


# ---------------------------------------------------------------------------
# Integration: IntelligenceEngine
# ---------------------------------------------------------------------------

@pytest.fixture
def engine(tmp_path):
    """Create a test engine with temporary memory path."""
    cfg = Config()
    cfg._data["memory"]["max_entries"] = 100
    eng = IntelligenceEngine(config=cfg)
    # Point memory to temp dir
    from pathlib import Path
    eng.memory.path = tmp_path / "memory.json"
    eng.initialize()
    return eng


class TestIntelligenceEngine:
    def test_initialize(self, engine):
        assert engine._ready is True

    def test_process_returns_string(self, engine):
        response = engine.process("What is Meta IA?")
        assert isinstance(response, str)
        assert len(response) > 0

    def test_memory_grows(self, engine):
        before = len(engine.memory)
        engine.process("Tell me something.")
        after = len(engine.memory)
        assert after == before + 2  # user + assistant entries

    def test_similarity_identical(self, engine):
        s = engine.similarity("intelligence program", "intelligence program")
        assert abs(s - 1.0) < 1e-6

    def test_similarity_different(self, engine):
        s = engine.similarity("apple pie recipe", "quantum physics equations")
        assert s < 0.5

    def test_stats_keys(self, engine):
        stats = engine.stats()
        for key in ("version", "memory_entries", "vocab_size", "index_shape", "ready"):
            assert key in stats

    def test_not_initialized_raises(self, tmp_path):
        from meta_ia.utils.config import Config
        eng = IntelligenceEngine(config=Config())
        eng.memory.path = tmp_path / "mem.json"
        with pytest.raises(RuntimeError):
            eng.process("hello")

    def test_retrieval_after_context(self, engine):
        engine.process("Meta IA is a powerful intelligence program.")
        engine.process("NumPy is used for vector computation.")
        results = engine._retrieve("intelligence program", top_k=3)
        assert len(results) >= 0  # may or may not match depending on vocab
