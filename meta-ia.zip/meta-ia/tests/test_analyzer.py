"""
tests/test_analyzer.py
======================
Unit tests for the Meta IA Analyzer module.
"""

import pytest
from meta_ia.core.analyzer import Analyzer


@pytest.fixture
def analyzer():
    return Analyzer()


class TestSentiment:
    def test_positive(self, analyzer):
        score = analyzer.sentiment("This is great and excellent work!")
        assert score > 0

    def test_negative(self, analyzer):
        score = analyzer.sentiment("This is terrible and broken software.")
        assert score < 0

    def test_neutral(self, analyzer):
        score = analyzer.sentiment("The file is located in the directory.")
        assert -0.5 < score < 0.5

    def test_empty(self, analyzer):
        assert analyzer.sentiment("") == 0.0


class TestKeywords:
    def test_returns_list(self, analyzer):
        kws = analyzer.keywords("Python is a powerful programming language for AI")
        assert isinstance(kws, list)

    def test_no_stopwords(self, analyzer):
        kws = analyzer.keywords("the quick brown fox jumps over the lazy dog")
        for w in ("the", "over", "is"):
            assert w not in kws

    def test_n_limit(self, analyzer):
        text = "machine learning deep learning neural network training data model"
        kws = analyzer.keywords(text, n=3)
        assert len(kws) <= 3

    def test_empty(self, analyzer):
        assert analyzer.keywords("") == []


class TestIntent:
    def test_question(self, analyzer):
        assert analyzer.intent("What is Meta IA?") == "question"

    def test_computation(self, analyzer):
        assert analyzer.intent("compute 12 + 34") == "computation"

    def test_comparison(self, analyzer):
        assert analyzer.intent("compare Python vs JavaScript") == "comparison"

    def test_help(self, analyzer):
        assert analyzer.intent("help me with this") == "help_request"

    def test_general(self, analyzer):
        assert analyzer.intent("lalala nothing matched") == "general"


class TestEntropy:
    def test_uniform_high_entropy(self, analyzer):
        tokens = ["a", "b", "c", "d", "e", "f", "g", "h"]
        assert analyzer.entropy(tokens) > 2.0

    def test_single_token_zero_entropy(self, analyzer):
        tokens = ["same"] * 10
        ent = analyzer.entropy(tokens)
        assert abs(ent) < 0.01

    def test_empty(self, analyzer):
        assert analyzer.entropy([]) == 0.0


class TestReadability:
    def test_range(self, analyzer):
        score = analyzer.readability("The quick brown fox jumps over the lazy dog.")
        assert 0.0 <= score <= 100.0

    def test_empty(self, analyzer):
        assert analyzer.readability("") == 50.0


class TestAnalyze:
    def test_full_pipeline(self, analyzer):
        result = analyzer.analyze("What is the best way to learn machine learning quickly?")
        assert "tokens" in result
        assert "sentiment" in result
        assert "intent" in result
        assert "keywords" in result
        assert "entropy" in result
        assert "readability" in result
        assert result["intent"] == "question"

    def test_word_count(self, analyzer):
        result = analyzer.analyze("one two three four five")
        assert result["word_count"] == 5
