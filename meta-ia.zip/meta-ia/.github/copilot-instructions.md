# GitHub Copilot Instructions — Meta IA
# =======================================
# This file guides GitHub Copilot when working on the Meta IA codebase.
# Place this at: .github/copilot-instructions.md

## Project Overview
Meta IA (Meta Intelligence Artificial) is a cross-platform AI desktop program
built in Python + NumPy + PyQt6. It runs locally on Windows, macOS, and Linux.

## Architecture
- `meta_ia/core/`     — Intelligence engine (NumPy vector ops, reasoning, memory)
- `meta_ia/ui/`       — PyQt6 desktop UI (dark theme, chat interface, dashboard)
- `meta_ia/models/`   — AI model backend connectors (Ollama, HuggingFace)
- `meta_ia/utils/`    — Config, logging utilities
- `tests/`            — pytest test suite

## Coding Standards
1. All public methods MUST have Google-style docstrings with Args/Returns.
2. Use type annotations on all function signatures.
3. Prefer NumPy array operations over Python loops for numeric work.
4. All numeric arrays use dtype=np.float64 unless specified.
5. Use threading.Lock for any shared mutable state.
6. PyQt6 slots should be connected with snake_case method names.
7. Use f-strings, not % or .format() except in logging calls.
8. Line length: 100 characters max.

## NumPy Patterns Used
- TF-IDF via np.zeros, np.log, np.dot
- Cosine similarity via np.linalg.norm, np.dot
- Top-k via np.argsort with [::-1][:k]
- Shannon entropy via np.log2, np.sum
- Stats via np.mean, np.std, np.max, np.min, np.clip

## Key Classes
- IntelligenceEngine  — Main brain; process(prompt) → str
- Analyzer            — analyze(text) → dict
- Reasoner            — reason(prompt, analysis, context) → str
- MemoryStore         — add(role, content); all_texts() → List[str]
- Config              — get(dotted.key), set(dotted.key, value)
- MetaIAMainWindow    — QMainWindow; hosts sidebar + stacked pages
- ChatWidget          — Chat UI; uses _WorkerThread for async engine calls
- ModelManager        — Pluggable LLM backends (rule/ollama/hf)

## Testing
- Run: pytest tests/ -v
- Coverage: pytest tests/ --cov=meta_ia
- All new modules need a corresponding test file in tests/

## Adding a New Feature
1. Add core logic in meta_ia/core/
2. Wire it into IntelligenceEngine if needed
3. Add a UI panel in meta_ia/ui/ if user-facing
4. Register the panel in MetaIAMainWindow._build_ui()
5. Write tests in tests/test_<module>.py
6. Update requirements.txt if new dependency added
