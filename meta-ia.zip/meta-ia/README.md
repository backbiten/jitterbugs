# Meta IA — Meta Intelligence Artificial

> **An independent, cross-platform intelligence program. Built in Python + NumPy.**
> Runs locally on Windows, macOS, and Linux. No cloud AI dependency.

---

## What is Meta IA?

**Meta IA** (Meta Intelligence Artificial) is an open-source, locally-running
intelligence program built from the ground up in Python and NumPy. It is
designed to operate independently — no Facebook, no external AI cloud service,
no subscription — just pure intelligence running on your machine.

### Core Capabilities
| Capability              | Description                                          |
|-------------------------|------------------------------------------------------|
| 💬 Chat Interface       | Dark-themed PyQt6 chat UI with async engine          |
| 🧠 Intelligence Engine  | NumPy-powered TF-IDF vector search + reasoning       |
| 📊 Analysis             | Sentiment, intent, keywords, entropy, readability    |
| 🔄 Memory               | Persistent conversation memory (JSON, survives restart) |
| ⚡ Reasoning            | Intent-aware rule + template response engine         |
| 🔌 Model Backends       | Plug in Ollama (LLaMA3) or HuggingFace Transformers  |
| 📦 Packaged Binaries    | PyInstaller builds for Win/Mac/Linux                 |

---

## Platform Support

| Platform | Status    |
|----------|-----------|
| Windows  | ✅ v1.0   |
| macOS    | ✅ v1.0   |
| Linux    | ✅ v1.0   |
| Android  | 🔜 v2.0   |
| iOS      | 🔜 v2.0   |

---

## Quick Start

### Prerequisites
- Python 3.10 or later
- pip

### Install

```bash
# Clone the repository
git clone https://github.com/your-org/meta-ia.git
cd meta-ia

# Create a virtual environment
python -m venv .venv

# Activate
# Windows:
.venv\Scripts\activate
# macOS / Linux:
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Run

```bash
python -m meta_ia.main
```

### Or install as a package

```bash
pip install -e .
meta-ia
```

---

## Project Structure

```
meta-ia/
├── meta_ia/
│   ├── main.py                 # Entry point
│   ├── core/
│   │   ├── intelligence.py     # IntelligenceEngine (NumPy)
│   │   ├── analyzer.py         # Text & data analysis
│   │   ├── reasoner.py         # Logical inference engine
│   │   └── memory.py           # Persistent memory store
│   ├── ui/
│   │   ├── main_window.py      # PyQt6 main window
│   │   ├── chat_widget.py      # Chat interface
│   │   ├── dashboard.py        # Stats dashboard
│   │   └── styles.py           # Dark theme QSS
│   ├── models/
│   │   └── model_manager.py    # Ollama / HuggingFace backends
│   └── utils/
│       ├── config.py           # App configuration
│       └── logger.py           # Logging setup
├── tests/
│   ├── test_intelligence.py
│   └── test_analyzer.py
├── .github/
│   ├── workflows/
│   │   ├── build.yml           # CI: Test all platforms
│   │   └── release.yml         # CD: Build binaries on tag
│   └── copilot-instructions.md # GitHub Copilot guidance
├── requirements.txt
├── requirements-dev.txt
├── pyproject.toml
└── LICENSE
```

---

## Enable Local LLM (Optional)

### Ollama (Recommended)

```bash
# Install Ollama: https://ollama.com
ollama pull llama3

# Install Python binding
pip install ollama

# In config (~/.meta_ia/config.json):
{
  "engine": {
    "model_backend": "ollama",
    "ollama_model": "llama3"
  }
}
```

### HuggingFace Transformers

```bash
pip install transformers torch

# In config:
{
  "engine": {
    "model_backend": "hf",
    "hf_model": "gpt2"
  }
}
```

---

## Development

```bash
# Install dev dependencies
pip install -r requirements-dev.txt

# Run tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=meta_ia

# Lint
ruff check meta_ia/

# Type check
mypy meta_ia/
```

---

## Build Standalone Binary

```bash
pip install pyinstaller

# Linux / macOS
pyinstaller --onefile --windowed --name meta-ia meta_ia/main.py

# Windows
pyinstaller --onefile --windowed --name meta-ia meta_ia\main.py
```

Binary output → `dist/meta-ia` (Linux/macOS) or `dist/meta-ia.exe` (Windows)

---

## GitHub Copilot

This project includes `.github/copilot-instructions.md` to guide Copilot
with project-specific patterns, conventions, and architecture context.

---

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/my-feature`)
3. Write code + tests
4. Run `pytest` and `ruff`
5. Open a Pull Request

---

## License

MIT — see [LICENSE](LICENSE)

---

## Roadmap

- [x] v1.0 — Desktop (Windows / macOS / Linux)
- [ ] v1.1 — Ollama LLM integration (full chat)
- [ ] v1.2 — File analysis (PDF, TXT, CSV)
- [ ] v1.3 — Web search integration
- [ ] v2.0 — Android & iOS (Flutter wrapper)
