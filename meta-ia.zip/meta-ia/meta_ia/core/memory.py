"""
meta_ia/core/memory.py
======================
Conversation and knowledge memory store for Meta IA.

Provides:
  - In-memory ring buffer backed by a JSON file on disk
  - Each entry: {role, content, timestamp}
  - NumPy used for statistical analysis of memory contents
  - Thread-safe access

GitHub Copilot Notes:
    - MemoryStore is append-only; entries are never deleted, only rotated.
    - max_entries controls the in-memory window; disk file keeps full history.
    - add(), all_texts(), load(), save() are the four methods you'll use most.
"""

from __future__ import annotations

import json
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

log = logging.getLogger("meta_ia.core.memory")

DEFAULT_MEMORY_PATH = Path.home() / ".meta_ia" / "memory.json"


class MemoryStore:
    """
    Meta IA Memory Store.

    Stores conversation turns and knowledge snippets in a bounded ring buffer.
    Persists to JSON on disk so memory survives restarts.

    Attributes:
        max_entries (int):         Maximum entries held in RAM.
        path        (Path):        Path to the JSON persistence file.
        _entries    (List[dict]):  In-memory list of memory entries.
        _lock       (Lock):        Thread lock.

    Example:
        >>> mem = MemoryStore(max_entries=512)
        >>> mem.load()
        >>> mem.add(role="user", content="Hello, Meta IA!")
        >>> texts = mem.all_texts()
    """

    def __init__(
        self,
        max_entries: int = 2048,
        path: Optional[Path] = None,
    ) -> None:
        self.max_entries = max_entries
        self.path        = path or DEFAULT_MEMORY_PATH
        self._entries:   List[Dict[str, Any]] = []
        self._lock       = threading.Lock()

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def add(self, role: str, content: str, metadata: Optional[Dict] = None) -> None:
        """
        Add a new entry to memory.

        Args:
            role:     'user' | 'assistant' | 'system'
            content:  The text content.
            metadata: Optional extra key-value pairs.
        """
        entry: Dict[str, Any] = {
            "role":      role,
            "content":   content,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        if metadata:
            entry.update(metadata)

        with self._lock:
            self._entries.append(entry)
            # Rotate if over capacity
            if len(self._entries) > self.max_entries:
                self._entries = self._entries[-self.max_entries:]

        log.debug("Memory entry added: role=%r, content_len=%d", role, len(content))

    def get_recent(self, n: int = 20) -> List[Dict[str, Any]]:
        """
        Return the n most recent memory entries.

        Args:
            n: Number of entries to return.

        Returns:
            List[dict]: Most recent entries, oldest first.
        """
        with self._lock:
            return list(self._entries[-n:])

    def all_texts(self) -> List[str]:
        """
        Return all stored content strings (for TF-IDF indexing).

        Returns:
            List[str]: Content strings.
        """
        with self._lock:
            return [e["content"] for e in self._entries]

    def search(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Simple keyword search over memory entries.

        Args:
            query: Search query string.
            top_k: Max results.

        Returns:
            List[dict]: Matching entries sorted by relevance.
        """
        query_lower = query.lower()
        with self._lock:
            scored = [
                (e, sum(1 for w in query_lower.split() if w in e["content"].lower()))
                for e in self._entries
            ]
        scored = [(e, s) for e, s in scored if s > 0]
        scored.sort(key=lambda x: x[1], reverse=True)
        return [e for e, _ in scored[:top_k]]

    def clear(self) -> None:
        """Clear all in-memory entries (does not delete disk file)."""
        with self._lock:
            self._entries.clear()
        log.info("Memory cleared.")

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def load(self) -> None:
        """Load entries from the JSON persistence file."""
        if not self.path.exists():
            log.info("No memory file found at %s; starting fresh.", self.path)
            return
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            with self._lock:
                self._entries = data.get("entries", [])
                # Enforce max_entries on load
                if len(self._entries) > self.max_entries:
                    self._entries = self._entries[-self.max_entries:]
            log.info("Loaded %d memory entries from %s.", len(self._entries), self.path)
        except Exception as exc:
            log.error("Failed to load memory file: %s", exc)

    def save(self) -> None:
        """Persist current entries to the JSON file."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with self._lock:
                data = {"entries": list(self._entries)}
            with open(self.path, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, ensure_ascii=False)
            log.info("Memory saved (%d entries) → %s", len(data["entries"]), self.path)
        except Exception as exc:
            log.error("Failed to save memory file: %s", exc)

    # ------------------------------------------------------------------
    # NumPy statistics
    # ------------------------------------------------------------------

    def stats(self) -> Dict[str, Any]:
        """
        Compute statistical summary of memory contents using NumPy.

        Returns:
            dict: entry_count, avg_length, std_length, max_length, roles.
        """
        with self._lock:
            entries = list(self._entries)

        if not entries:
            return {"entry_count": 0}

        lengths = np.array([len(e["content"]) for e in entries], dtype=np.float64)
        roles   = {}
        for e in entries:
            roles[e["role"]] = roles.get(e["role"], 0) + 1

        return {
            "entry_count": len(entries),
            "avg_length":  float(np.mean(lengths)),
            "std_length":  float(np.std(lengths)),
            "max_length":  int(np.max(lengths)),
            "min_length":  int(np.min(lengths)),
            "roles":       roles,
        }

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        with self._lock:
            return len(self._entries)

    def __repr__(self) -> str:
        return f"MemoryStore(entries={len(self)}, max={self.max_entries}, path={self.path})"
