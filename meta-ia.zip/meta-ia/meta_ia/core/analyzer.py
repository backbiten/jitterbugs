"""
meta_ia/core/analyzer.py
========================
Text and data analysis module for Meta IA.

Uses NumPy for all numeric computation:
  - Sentiment scoring via lexicon + weighted NumPy dot product
  - Statistical descriptors (mean, std, entropy)
  - Keyword extraction via TF scoring
  - Intent classification (rule + vector hybrid)

GitHub Copilot Notes:
    - Analyzer is stateless: all methods take inputs, return outputs.
    - Sentiment lexicon is intentionally minimal; extend POSITIVE/NEGATIVE dicts.
    - All numeric work uses np.float64 for precision.
"""

from __future__ import annotations

import re
import math
import logging
from typing import Any, Dict, List, Tuple

import numpy as np

log = logging.getLogger("meta_ia.core.analyzer")

# ---------------------------------------------------------------------------
# Sentiment lexicons (extend as needed)
# ---------------------------------------------------------------------------

POSITIVE_WORDS: Dict[str, float] = {
    "good": 1.0, "great": 1.5, "excellent": 2.0, "amazing": 2.0,
    "wonderful": 1.8, "fantastic": 1.8, "happy": 1.2, "love": 1.5,
    "best": 1.5, "perfect": 2.0, "brilliant": 1.8, "smart": 1.2,
    "helpful": 1.2, "correct": 1.0, "right": 0.8, "yes": 0.5,
    "beautiful": 1.5, "fast": 1.0, "powerful": 1.3, "clear": 0.8,
}

NEGATIVE_WORDS: Dict[str, float] = {
    "bad": -1.0, "terrible": -2.0, "awful": -2.0, "horrible": -2.0,
    "wrong": -1.0, "slow": -0.8, "broken": -1.5, "error": -1.2,
    "fail": -1.5, "failed": -1.5, "hate": -2.0, "ugly": -1.3,
    "poor": -1.2, "useless": -1.8, "stupid": -1.5, "boring": -0.8,
    "confusing": -1.0, "difficult": -0.6, "crash": -1.5, "bug": -1.0,
}

# ---------------------------------------------------------------------------
# Intent rules
# ---------------------------------------------------------------------------

INTENT_PATTERNS: List[Tuple[str, str]] = [
    (r"\b(what|who|where|when|why|how)\b",          "question"),
    (r"\b(calculate|compute|sum|add|multiply)\b",   "computation"),
    (r"\b(compare|vs|versus|difference|better)\b",  "comparison"),
    (r"\b(help|assist|support|guide|explain)\b",    "help_request"),
    (r"\b(run|execute|start|launch|open)\b",        "command"),
    (r"\b(show|display|list|print|output)\b",       "display"),
    (r"\b(save|store|remember|keep|record)\b",      "memory_write"),
    (r"\b(search|find|look|query|retrieve)\b",      "search"),
    (r"\b(analyze|analyse|check|inspect|scan)\b",   "analysis"),
    (r"\b(create|build|make|generate|produce)\b",   "creation"),
]


class Analyzer:
    """
    Meta IA Text and Data Analyzer.

    Provides NLP-lite analysis using Python + NumPy only (no external NLP
    libraries required). Designed to be extended with HuggingFace Transformers
    when heavy-weight analysis is needed.

    Methods:
        analyze(text)       → Full analysis dict
        sentiment(text)     → float score
        keywords(text, n)   → List[str]
        intent(text)        → str
        entropy(text)       → float
        readability(text)   → float
    """

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def analyze(self, text: str) -> Dict[str, Any]:
        """
        Run full analysis pipeline on input text.

        Args:
            text: Raw input string.

        Returns:
            dict with keys: tokens, word_count, char_count, sentiment,
                            sentiment_label, intent, keywords, entropy, readability.
        """
        tokens     = self._tokenize(text)
        word_count = len(tokens)
        char_count = len(text)
        sent_score = self.sentiment(text)
        kws        = self.keywords(text, n=10)
        ent        = self.entropy(tokens)
        read       = self.readability(text)
        intent_cls = self.intent(text)

        if sent_score > 0.3:
            label = "positive"
        elif sent_score < -0.3:
            label = "negative"
        else:
            label = "neutral"

        result: Dict[str, Any] = {
            "tokens":          tokens,
            "word_count":      word_count,
            "char_count":      char_count,
            "sentiment":       round(sent_score, 4),
            "sentiment_label": label,
            "intent":          intent_cls,
            "keywords":        kws,
            "entropy":         round(ent, 4),
            "readability":     round(read, 4),
        }
        log.debug("Analysis result: %s", {k: v for k, v in result.items() if k != "tokens"})
        return result

    # ------------------------------------------------------------------
    # Sentiment
    # ------------------------------------------------------------------

    def sentiment(self, text: str) -> float:
        """
        Compute sentiment score using a lexicon + NumPy weighted sum.

        Args:
            text: Input text.

        Returns:
            float: Score > 0 positive, < 0 negative, ~0 neutral.
        """
        tokens = self._tokenize(text)
        if not tokens:
            return 0.0

        scores = np.array(
            [POSITIVE_WORDS.get(t, 0.0) + NEGATIVE_WORDS.get(t, 0.0) for t in tokens],
            dtype=np.float64,
        )
        # Normalise by doc length to avoid length bias
        return float(np.sum(scores) / math.sqrt(len(tokens)))

    # ------------------------------------------------------------------
    # Keywords
    # ------------------------------------------------------------------

    def keywords(self, text: str, n: int = 10) -> List[str]:
        """
        Extract top-n keywords by term frequency (NumPy argsort).

        Args:
            text: Input text.
            n:    Number of keywords to return.

        Returns:
            List[str]: Top-n keywords.
        """
        STOPWORDS = {
            "the", "a", "an", "is", "it", "to", "of", "and", "or", "in",
            "on", "at", "for", "with", "this", "that", "be", "as", "by",
            "are", "was", "were", "has", "have", "had", "do", "does", "did",
            "will", "would", "could", "should", "may", "might", "can", "not",
            "but", "if", "so", "we", "you", "i", "my", "your", "our", "their",
            "over", "up", "out", "its", "than", "then", "just", "also",
        }
        tokens = [t for t in self._tokenize(text) if t not in STOPWORDS and len(t) > 2]
        if not tokens:
            return []

        unique, counts = np.unique(tokens, return_counts=True)
        top_idx = np.argsort(counts)[::-1][:n]
        return unique[top_idx].tolist()

    # ------------------------------------------------------------------
    # Intent Classification
    # ------------------------------------------------------------------

    def intent(self, text: str) -> str:
        """
        Rule-based intent classification using regex patterns.

        Args:
            text: Input text.

        Returns:
            str: Intent label (e.g. 'question', 'command', 'help_request').
        """
        lower = text.lower()
        for pattern, label in INTENT_PATTERNS:
            if re.search(pattern, lower):
                return label
        return "general"

    # ------------------------------------------------------------------
    # Entropy
    # ------------------------------------------------------------------

    def entropy(self, tokens: List[str]) -> float:
        """
        Compute Shannon entropy of the token distribution (NumPy).

        Args:
            tokens: List of word tokens.

        Returns:
            float: Entropy in bits.
        """
        if not tokens:
            return 0.0
        _, counts = np.unique(tokens, return_counts=True)
        probs = counts.astype(np.float64) / counts.sum()
        # H = -sum(p * log2(p))
        return float(-np.sum(probs * np.log2(probs + 1e-12)))

    # ------------------------------------------------------------------
    # Readability (Flesch-Kincaid approximation, NumPy)
    # ------------------------------------------------------------------

    def readability(self, text: str) -> float:
        """
        Approximate Flesch Reading Ease score using NumPy.
        Score: 100 = very easy, 0 = very hard.

        Args:
            text: Raw text.

        Returns:
            float: Reading ease score [0, 100].
        """
        sentences = re.split(r"[.!?]+", text)
        sentences = [s.strip() for s in sentences if s.strip()]
        if not sentences:
            return 50.0

        words = self._tokenize(text)
        if not words:
            return 50.0

        # Count syllables heuristically (vowel groups)
        syllable_counts = np.array(
            [len(re.findall(r"[aeiou]+", w)) or 1 for w in words],
            dtype=np.float64,
        )

        n_words     = float(len(words))
        n_sentences = float(len(sentences))
        n_syllables = float(np.sum(syllable_counts))

        score = 206.835 - 1.015 * (n_words / n_sentences) - 84.6 * (n_syllables / n_words)
        return float(np.clip(score, 0.0, 100.0))

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        """Lowercase and split text into word tokens."""
        text = text.lower()
        text = re.sub(r"[^a-z0-9\s]", " ", text)
        return [t for t in text.split() if len(t) > 1]
