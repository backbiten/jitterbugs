"""
meta_ia/core/__init__.py
========================
Core intelligence package for Meta IA.

Modules:
    intelligence  — Main IntelligenceEngine (NumPy-powered)
    analyzer      — Text, data, and pattern analysis
    reasoner      — Logical inference and chain-of-thought
    memory        — Conversation and context memory store
"""

from meta_ia.core.intelligence import IntelligenceEngine
from meta_ia.core.analyzer    import Analyzer
from meta_ia.core.reasoner    import Reasoner
from meta_ia.core.memory      import MemoryStore

__all__ = ["IntelligenceEngine", "Analyzer", "Reasoner", "MemoryStore"]
