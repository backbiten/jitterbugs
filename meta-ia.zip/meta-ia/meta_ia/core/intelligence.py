"""
meta_ia/core/intelligence.py
============================
The Meta IA Intelligence Engine — the core brain of the program.

This module uses NumPy for all vector and matrix operations, providing:
  - Semantic vector embedding (TF-IDF + SVD via NumPy)
  - Cosine similarity search across memory
  - Pattern recognition via matrix decomposition
  - Statistical reasoning layer
  - Model routing (local Ollama / HuggingFace fallback)

GitHub Copilot Notes:
    - All public methods are fully type-annotated.
    - NumPy arrays are preferred over Python lists for all numeric work.
    - The engine is stateful: call initialize() before process().
    - Thread-safe: uses threading.Lock for shared state.
"""

from __future__ import annotations

import re
import math
import logging
import threading
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from meta_ia.core.memory   import MemoryStore
from meta_ia.core.analyzer import Analyzer
from meta_ia.core.reasoner import Reasoner
from meta_ia.utils.config  import Config

log = logging.getLogger("meta_ia.core.intelligence")


# ---------------------------------------------------------------------------
# Vocabulary / TF-IDF helpers (pure NumPy — no sklearn dependency)
# ---------------------------------------------------------------------------

def _tokenize(text: str) -> List[str]:
    """Lowercase, strip punctuation, split on whitespace."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return [t for t in text.split() if len(t) > 1]


def _build_vocab(corpus: List[str]) -> Dict[str, int]:
    """Build a word → index vocabulary from a corpus of strings."""
    vocab: Dict[str, int] = {}
    for doc in corpus:
        for token in _tokenize(doc):
            if token not in vocab:
                vocab[token] = len(vocab)
    return vocab


def _tfidf_matrix(corpus: List[str], vocab: Dict[str, int]) -> np.ndarray:
    """
    Compute TF-IDF matrix of shape (n_docs, vocab_size) using NumPy only.

    Args:
        corpus: List of raw text strings.
        vocab:  Word → column-index mapping.

    Returns:
        np.ndarray: TF-IDF matrix, float64.
    """
    n_docs = len(corpus)
    n_vocab = len(vocab)
    tf = np.zeros((n_docs, n_vocab), dtype=np.float64)

    for d_idx, doc in enumerate(corpus):
        tokens = _tokenize(doc)
        if not tokens:
            continue
        for token in tokens:
            if token in vocab:
                tf[d_idx, vocab[token]] += 1.0
        tf[d_idx] /= len(tokens)  # term frequency normalisation

    # IDF: log((1 + n) / (1 + df)) + 1
    df = np.count_nonzero(tf, axis=0).astype(np.float64)
    idf = np.log((1.0 + n_docs) / (1.0 + df)) + 1.0
    return tf * idf


def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """
    Compute cosine similarity between two 1-D vectors.

    Args:
        a: First vector.
        b: Second vector.

    Returns:
        float: Similarity score in [-1, 1].
    """
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return float(np.dot(a, b) / (norm_a * norm_b))


def _top_k_indices(scores: np.ndarray, k: int) -> np.ndarray:
    """Return the indices of the top-k highest scores."""
    k = min(k, len(scores))
    return np.argsort(scores)[::-1][:k]


# ---------------------------------------------------------------------------
# IntelligenceEngine
# ---------------------------------------------------------------------------

class IntelligenceEngine:
    """
    Meta IA — Intelligence Engine.

    The central processing unit of the Meta IA program. Orchestrates the
    Analyzer, Reasoner, and MemoryStore, and exposes a single high-level
    `process(prompt)` interface to the UI layer.

    Attributes:
        config    (Config):       Application configuration.
        memory    (MemoryStore):  Persistent conversation and knowledge memory.
        analyzer  (Analyzer):     Text and data analysis module.
        reasoner  (Reasoner):     Logical inference module.
        _lock     (Lock):         Thread lock for safe concurrent access.
        _vocab    (dict):         Current TF-IDF vocabulary.
        _tfidf    (np.ndarray):   TF-IDF matrix of memory entries.
        _ready    (bool):         True after initialize() completes.

    Example:
        >>> engine = IntelligenceEngine(config=Config())
        >>> engine.initialize()
        >>> response = engine.process("What is the meaning of intelligence?")
    """

    VERSION = "1.0.0"

    def __init__(self, config: Optional[Config] = None) -> None:
        self.config   = config or Config()
        self.memory   = MemoryStore(max_entries=self.config.get("memory.max_entries", 2048))
        self.analyzer = Analyzer()
        self.reasoner = Reasoner()
        self._lock    = threading.Lock()
        self._vocab:  Dict[str, int] = {}
        self._tfidf:  np.ndarray     = np.empty((0,), dtype=np.float64)
        self._ready   = False
        log.debug("IntelligenceEngine instance created (not yet initialized).")

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def initialize(self) -> None:
        """
        Warm up the engine: load memory, build vocabulary, pre-compute embeddings.
        Must be called once before process().
        """
        with self._lock:
            log.info("Initializing Meta IA Intelligence Engine v%s…", self.VERSION)
            self.memory.load()
            self._rebuild_index()
            self._ready = True
            log.info("Intelligence Engine initialized. Memory entries: %d", len(self.memory))

    def shutdown(self) -> None:
        """Persist memory and release resources gracefully."""
        with self._lock:
            log.info("Shutting down Intelligence Engine…")
            self.memory.save()
            self._ready = False

    # ------------------------------------------------------------------
    # Primary Interface
    # ------------------------------------------------------------------

    def process(self, prompt: str, context: Optional[List[str]] = None) -> str:
        """
        Process a user prompt through the full Meta IA pipeline:
            1. Analyze the input
            2. Retrieve relevant memory context (NumPy cosine search)
            3. Reason over context + prompt
            4. Generate and store a response
            5. Update memory index

        Args:
            prompt:  The raw user input string.
            context: Optional additional context strings.

        Returns:
            str: The Meta IA response.

        Raises:
            RuntimeError: If initialize() has not been called.
        """
        if not self._ready:
            raise RuntimeError("IntelligenceEngine.initialize() must be called before process().")

        with self._lock:
            log.debug("Processing prompt: %.80s…", prompt)

            # Step 1 — Analyze
            analysis = self.analyzer.analyze(prompt)
            log.debug("Analysis: %s", analysis)

            # Step 2 — Retrieve memory context
            retrieved = self._retrieve(prompt, top_k=self.config.get("engine.top_k", 5))
            log.debug("Retrieved %d memory entries.", len(retrieved))

            # Step 3 — Reason
            all_context = (context or []) + retrieved
            response = self.reasoner.reason(
                prompt=prompt,
                analysis=analysis,
                context=all_context,
            )

            # Step 4 — Store in memory
            self.memory.add(role="user",      content=prompt)
            self.memory.add(role="assistant", content=response)

            # Step 5 — Rebuild index incrementally
            self._rebuild_index()

            return response

    # ------------------------------------------------------------------
    # Vector Search (NumPy)
    # ------------------------------------------------------------------

    def _rebuild_index(self) -> None:
        """
        Rebuild the TF-IDF index over the current memory contents.
        Called after every process() to keep the index fresh.
        """
        corpus = self.memory.all_texts()
        if not corpus:
            self._vocab = {}
            self._tfidf = np.empty((0,), dtype=np.float64)
            return

        self._vocab = _build_vocab(corpus)
        self._tfidf = _tfidf_matrix(corpus, self._vocab)
        log.debug("Index rebuilt: %d docs × %d terms.", self._tfidf.shape[0], self._tfidf.shape[1])

    def _retrieve(self, query: str, top_k: int = 5) -> List[str]:
        """
        Retrieve the top-k most relevant memory entries for a query using
        NumPy cosine similarity over the TF-IDF index.

        Args:
            query: The query string.
            top_k: Number of results to return.

        Returns:
            List[str]: Most relevant memory text entries.
        """
        if self._tfidf.size == 0 or not self._vocab:
            return []

        # Embed query
        q_vec = _tfidf_matrix([query], self._vocab)[0]

        # Compute cosine similarity against all memory rows
        scores = np.array([
            _cosine_similarity(q_vec, self._tfidf[i])
            for i in range(self._tfidf.shape[0])
        ], dtype=np.float64)

        # Get top-k indices
        top_indices = _top_k_indices(scores, k=top_k)
        texts = self.memory.all_texts()
        return [texts[i] for i in top_indices if scores[i] > 0.0]

    # ------------------------------------------------------------------
    # Introspection Helpers
    # ------------------------------------------------------------------

    def similarity(self, text_a: str, text_b: str) -> float:
        """
        Public utility: compute semantic similarity between two strings.

        Args:
            text_a: First string.
            text_b: Second string.

        Returns:
            float: Cosine similarity score [0, 1].
        """
        corpus = [text_a, text_b]
        vocab  = _build_vocab(corpus)
        matrix = _tfidf_matrix(corpus, vocab)
        return max(0.0, _cosine_similarity(matrix[0], matrix[1]))

    def stats(self) -> Dict[str, Any]:
        """
        Return engine statistics for the dashboard.

        Returns:
            dict: Keys — version, memory_entries, vocab_size, index_shape, ready.
        """
        return {
            "version":        self.VERSION,
            "memory_entries": len(self.memory),
            "vocab_size":     len(self._vocab),
            "index_shape":    list(self._tfidf.shape) if self._tfidf.ndim == 2 else [0, 0],
            "ready":          self._ready,
        }

    def __repr__(self) -> str:
        return (
            f"IntelligenceEngine(version={self.VERSION!r}, "
            f"ready={self._ready}, memory={len(self.memory)})"
        )
