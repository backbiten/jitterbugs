"""
meta_ia/core/reasoner.py
========================
Logical inference and response generation for Meta IA.

The Reasoner takes a prompt, an analysis dict from the Analyzer, and a list
of retrieved memory context strings, then constructs a coherent, grounded
response. It uses NumPy for context ranking and score aggregation.

Architecture:
    - Rule templates handle structured intents (computation, comparison, etc.)
    - Context-weighted scoring selects the best supporting evidence
    - A fallback generation path handles open-ended queries

GitHub Copilot Notes:
    - reason() is the single entry point; do not call private methods directly.
    - Extend TEMPLATES to add new response patterns.
    - model_backend can be swapped for Ollama/HuggingFace in ModelManager.
"""

from __future__ import annotations

import re
import logging
import math
from typing import Any, Dict, List, Optional

import numpy as np

log = logging.getLogger("meta_ia.core.reasoner")


# ---------------------------------------------------------------------------
# Response templates keyed by intent
# ---------------------------------------------------------------------------

TEMPLATES: Dict[str, str] = {
    "question":    "Based on what I know: {context_summary}\n\nIn response to your question — {prompt}",
    "computation": "Let me work through that computation for you.\n\n{computation_result}",
    "comparison":  "Here is a structured comparison:\n\n{comparison_body}",
    "help_request":"I'm here to help. {help_body}",
    "command":     "Executing your request: {prompt}\n\n{command_result}",
    "display":     "{display_body}",
    "memory_write":"I've noted that: \"{prompt}\".\nThis has been stored in my memory.",
    "search":      "Searching my knowledge for: \"{prompt}\"\n\n{search_results}",
    "analysis":    "Analysis results for your input:\n\n{analysis_body}",
    "creation":    "Here is what I've generated based on your request:\n\n{creation_body}",
    "general":     "{general_response}",
}


class Reasoner:
    """
    Meta IA Reasoning Engine.

    Constructs intelligent responses from:
        - The original prompt
        - Structured analysis (from Analyzer)
        - Retrieved memory context (from MemoryStore via IntelligenceEngine)

    The response pipeline:
        1. Select response template from intent
        2. Rank context by relevance score (NumPy)
        3. Summarise top context
        4. Fill template
        5. Post-process (trim, capitalise, punctuate)

    Attributes:
        model_backend: Optional callable(prompt, context) → str.
                       If set, delegates final generation to an LLM backend.
    """

    def __init__(self, model_backend: Optional[Any] = None) -> None:
        self.model_backend = model_backend
        log.debug("Reasoner initialised (backend=%s).", model_backend)

    # ------------------------------------------------------------------
    # Primary interface
    # ------------------------------------------------------------------

    def reason(
        self,
        prompt:   str,
        analysis: Dict[str, Any],
        context:  List[str],
    ) -> str:
        """
        Generate a response for the given prompt.

        Args:
            prompt:   Original user input.
            analysis: Output from Analyzer.analyze(prompt).
            context:  List of relevant memory/context strings.

        Returns:
            str: The Meta IA response text.
        """
        intent = analysis.get("intent", "general")
        log.debug("Reasoning with intent=%r, context_len=%d", intent, len(context))

        # If a model backend is registered, delegate
        if self.model_backend is not None:
            try:
                return self.model_backend(prompt, context)
            except Exception as exc:
                log.warning("Model backend failed (%s); falling back to rule engine.", exc)

        # --- Rule-based path ---
        ctx_summary = self._summarise_context(context, prompt)

        if intent == "computation":
            return self._handle_computation(prompt)
        if intent == "comparison":
            return self._handle_comparison(prompt, ctx_summary)
        if intent == "help_request":
            return self._handle_help(prompt, ctx_summary)
        if intent == "analysis":
            return self._handle_analysis(prompt, analysis)
        if intent == "memory_write":
            return TEMPLATES["memory_write"].format(prompt=prompt)
        if intent == "search":
            return self._handle_search(prompt, context)
        if intent == "display":
            return self._handle_display(prompt, context)
        if intent == "question":
            return TEMPLATES["question"].format(
                context_summary=ctx_summary or "I don't have prior context on this yet.",
                prompt=prompt,
            )

        # General fallback
        return self._handle_general(prompt, analysis, ctx_summary)

    # ------------------------------------------------------------------
    # Context ranking (NumPy)
    # ------------------------------------------------------------------

    def _summarise_context(self, context: List[str], query: str, top_n: int = 3) -> str:
        """
        Rank context strings by simple overlap score with the query,
        then return the top-N joined as a paragraph.

        Args:
            context: List of candidate context strings.
            query:   The original prompt for relevance scoring.
            top_n:   How many context snippets to include.

        Returns:
            str: Summarised context paragraph.
        """
        if not context:
            return ""

        query_tokens = set(re.sub(r"[^a-z0-9\s]", " ", query.lower()).split())

        # Score = number of shared tokens (NumPy for the arithmetic)
        scores = np.array([
            len(query_tokens & set(re.sub(r"[^a-z0-9\s]", " ", c.lower()).split()))
            for c in context
        ], dtype=np.float64)

        top_idx = np.argsort(scores)[::-1][:top_n]
        top_ctx = [context[i] for i in top_idx if scores[i] > 0]

        if not top_ctx:
            return context[0][:300] if context else ""

        return " | ".join(c[:200] for c in top_ctx)

    # ------------------------------------------------------------------
    # Intent handlers
    # ------------------------------------------------------------------

    def _handle_computation(self, prompt: str) -> str:
        """Attempt to evaluate a numeric expression found in the prompt."""
        # Extract numeric expressions safely
        expr_match = re.search(r"[\d\s\+\-\*\/\(\)\.\^]+", prompt)
        if expr_match:
            raw = expr_match.group().strip().replace("^", "**")
            try:
                # Only allow safe math evaluation
                allowed = set("0123456789+-*/(). ")
                if all(c in allowed for c in raw):
                    result = eval(raw, {"__builtins__": {}}, {})  # noqa: S307
                    return (
                        f"Computation:\n"
                        f"  Expression : {raw}\n"
                        f"  Result     : {result}\n\n"
                        f"Meta IA computed this using its arithmetic engine."
                    )
            except Exception:
                pass
        return (
            f"I understood this as a computation request: \"{prompt}\"\n"
            "However, I couldn't extract a clear numeric expression to evaluate. "
            "Please provide a specific mathematical expression (e.g. '12 * 34 + 5')."
        )

    def _handle_comparison(self, prompt: str, ctx_summary: str) -> str:
        """Generate a structured comparison response."""
        # Try to extract two subjects from 'X vs Y' or 'compare X and Y'
        vs_match = re.search(
            r"(?:compare\s+)?(.+?)\s+(?:vs\.?|versus|vs|compared to|and)\s+(.+)",
            prompt, re.IGNORECASE
        )
        if vs_match:
            a, b = vs_match.group(1).strip(), vs_match.group(2).strip()
            return (
                f"Comparing: {a.title()}  vs.  {b.title()}\n"
                f"{'─'*50}\n"
                f"• {a.title()}: {ctx_summary or 'No specific data in memory yet.'}\n"
                f"• {b.title()}: Please add more context about {b} for a deeper comparison.\n\n"
                f"Meta IA recommends providing more details for a richer analysis."
            )
        return f"Comparison request noted: \"{prompt}\"\n\n{ctx_summary or 'No context found yet.'}"

    def _handle_help(self, prompt: str, ctx_summary: str) -> str:
        """Respond to help/assistance requests."""
        return (
            f"I'm Meta IA — Meta Intelligence Artificial. I'm here to help.\n\n"
            f"Your request: \"{prompt}\"\n\n"
            f"{'Relevant context: ' + ctx_summary if ctx_summary else ''}\n\n"
            f"What would you like me to do specifically? I can:\n"
            f"  • Analyse text and data\n"
            f"  • Compare topics\n"
            f"  • Answer questions\n"
            f"  • Remember and retrieve information\n"
            f"  • Perform computations\n"
            f"  • Assist with research and reasoning\n"
        )

    def _handle_analysis(self, prompt: str, analysis: Dict[str, Any]) -> str:
        """Format an analysis report from the Analyzer output."""
        kw_str = ", ".join(analysis.get("keywords", [])[:5]) or "none detected"
        return (
            f"Meta IA Analysis Report\n"
            f"{'─'*40}\n"
            f"Input        : \"{prompt[:80]}{'…' if len(prompt) > 80 else ''}\"\n"
            f"Word Count   : {analysis.get('word_count', 0)}\n"
            f"Sentiment    : {analysis.get('sentiment_label', 'neutral')} "
            f"(score: {analysis.get('sentiment', 0.0):.3f})\n"
            f"Intent       : {analysis.get('intent', 'general')}\n"
            f"Keywords     : {kw_str}\n"
            f"Entropy      : {analysis.get('entropy', 0.0):.3f} bits\n"
            f"Readability  : {analysis.get('readability', 50.0):.1f}/100\n"
            f"{'─'*40}\n"
        )

    def _handle_search(self, prompt: str, context: List[str]) -> str:
        """Format search results from memory context."""
        if not context:
            return f"I searched my memory for \"{prompt}\" but found no relevant entries yet."
        results = "\n".join(f"  [{i+1}] {c[:200]}" for i, c in enumerate(context[:5]))
        return f"Memory search results for: \"{prompt}\"\n\n{results}"

    def _handle_display(self, prompt: str, context: List[str]) -> str:
        """Format display/list requests."""
        if context:
            items = "\n".join(f"  • {c[:200]}" for c in context[:10])
            return f"Displaying relevant information:\n\n{items}"
        return f"Display request: \"{prompt}\"\n\nNo stored data found matching this request."

    def _handle_general(
        self, prompt: str, analysis: Dict[str, Any], ctx_summary: str
    ) -> str:
        """Fallback general response handler."""
        kw_str = ", ".join(analysis.get("keywords", [])[:3])
        ctx_part = f"\n\nContext I found: {ctx_summary}" if ctx_summary else ""
        kw_part  = f"\n\nKey topics I identified: {kw_str}" if kw_str else ""
        return (
            f"Meta IA received your message: \"{prompt}\"\n"
            f"{ctx_part}"
            f"{kw_part}\n\n"
            f"I'm continuously learning. The more you interact with me, "
            f"the more accurately I can respond."
        )
