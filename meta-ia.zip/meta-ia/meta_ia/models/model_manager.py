"""
meta_ia/models/model_manager.py
================================
AI model backend manager for Meta IA.

Supports:
  1. Rule engine (default — no external dependencies)
  2. Ollama local LLM  (requires: pip install ollama)
  3. HuggingFace Transformers (requires: pip install transformers torch)

Usage (plug into Reasoner):
    >>> mm = ModelManager(backend="ollama", model="llama3")
    >>> mm.connect()
    >>> reasoner = Reasoner(model_backend=mm.generate)

GitHub Copilot Notes:
    - ModelManager.generate(prompt, context) is the callable interface.
    - backend="rule" uses no external model (fully offline, zero deps).
    - backend="ollama" requires Ollama server running locally.
    - backend="hf" loads model into RAM (requires ~4–8 GB for LLaMA-3).
"""

from __future__ import annotations

import logging
from typing import Callable, List, Optional

log = logging.getLogger("meta_ia.models.model_manager")


class ModelManager:
    """
    Meta IA Model Backend Manager.

    Manages the connection to an AI language model backend and provides
    a unified generate() callable for the Reasoner.

    Attributes:
        backend (str):   'rule' | 'ollama' | 'hf'
        model   (str):   Model name/path.
        _client:         Backend-specific client object.
        _pipeline:       HuggingFace pipeline (if backend='hf').
        connected (bool):True after connect() succeeds.
    """

    SUPPORTED_BACKENDS = ("rule", "ollama", "hf")

    def __init__(
        self,
        backend: str = "rule",
        model:   str = "llama3",
    ) -> None:
        if backend not in self.SUPPORTED_BACKENDS:
            raise ValueError(
                f"Unknown backend {backend!r}. Choose from {self.SUPPORTED_BACKENDS}."
            )
        self.backend   = backend
        self.model     = model
        self._client   = None
        self._pipeline = None
        self.connected = False
        log.info("ModelManager created: backend=%r, model=%r", backend, model)

    # ------------------------------------------------------------------
    # Connect
    # ------------------------------------------------------------------

    def connect(self) -> bool:
        """
        Initialise the model backend.

        Returns:
            bool: True on success, False on failure.
        """
        if self.backend == "rule":
            self.connected = True
            log.info("Rule engine backend active (no external model).")
            return True

        if self.backend == "ollama":
            return self._connect_ollama()

        if self.backend == "hf":
            return self._connect_hf()

        return False

    def _connect_ollama(self) -> bool:
        try:
            import ollama  # type: ignore
            # Verify the model is available
            models = ollama.list()
            available = [m["name"] for m in models.get("models", [])]
            if self.model not in available:
                log.warning(
                    "Ollama model %r not found locally. Pull it with: ollama pull %s",
                    self.model, self.model,
                )
            self._client   = ollama
            self.connected = True
            log.info("Ollama backend connected: model=%r", self.model)
            return True
        except ImportError:
            log.error("ollama package not installed. Run: pip install ollama")
        except Exception as exc:
            log.error("Ollama connection failed: %s", exc)
        return False

    def _connect_hf(self) -> bool:
        try:
            from transformers import pipeline  # type: ignore
            log.info("Loading HuggingFace model %r (may take a moment)…", self.model)
            self._pipeline = pipeline(
                "text-generation",
                model=self.model,
                max_new_tokens=512,
                do_sample=True,
                temperature=0.7,
            )
            self.connected = True
            log.info("HuggingFace backend connected: model=%r", self.model)
            return True
        except ImportError:
            log.error("transformers package not installed. Run: pip install transformers torch")
        except Exception as exc:
            log.error("HuggingFace model load failed: %s", exc)
        return False

    # ------------------------------------------------------------------
    # Generate
    # ------------------------------------------------------------------

    def generate(self, prompt: str, context: Optional[List[str]] = None) -> str:
        """
        Generate a response using the configured backend.

        Args:
            prompt:  User input string.
            context: Optional list of context strings.

        Returns:
            str: Generated response text.

        Raises:
            RuntimeError: If connect() has not been called or failed.
        """
        if not self.connected:
            raise RuntimeError("ModelManager.connect() must be called first.")

        ctx_block = "\n".join(context[:5]) if context else ""
        full_prompt = f"{ctx_block}\n\nUser: {prompt}\nMeta IA:" if ctx_block else f"User: {prompt}\nMeta IA:"

        if self.backend == "ollama":
            return self._generate_ollama(full_prompt)

        if self.backend == "hf":
            return self._generate_hf(full_prompt)

        # rule backend — caller should use Reasoner directly
        return f"(rule backend) Received: {prompt}"

    def _generate_ollama(self, prompt: str) -> str:
        try:
            response = self._client.chat(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
            )
            return response["message"]["content"].strip()
        except Exception as exc:
            log.error("Ollama generation error: %s", exc)
            raise

    def _generate_hf(self, prompt: str) -> str:
        try:
            outputs = self._pipeline(prompt, max_new_tokens=256)
            text = outputs[0]["generated_text"]
            # Strip the input prompt from the output
            if text.startswith(prompt):
                text = text[len(prompt):]
            return text.strip()
        except Exception as exc:
            log.error("HuggingFace generation error: %s", exc)
            raise

    # ------------------------------------------------------------------
    # Info
    # ------------------------------------------------------------------

    def info(self) -> dict:
        return {
            "backend":   self.backend,
            "model":     self.model,
            "connected": self.connected,
        }

    def __repr__(self) -> str:
        return f"ModelManager(backend={self.backend!r}, model={self.model!r}, connected={self.connected})"
