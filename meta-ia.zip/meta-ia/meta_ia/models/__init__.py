"""
meta_ia/models/__init__.py
"""
from meta_ia.models.model_manager import ModelManager
__all__ = ["ModelManager"]
