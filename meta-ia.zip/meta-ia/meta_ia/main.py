"""
meta_ia/main.py
===============
Entry point for the Meta IA Desktop Application.

Usage:
    python -m meta_ia.main
    or
    python main.py (from project root)

GitHub Copilot Notes:
    - This file bootstraps the PyQt6 application loop.
    - It initializes the IntelligenceEngine before launching the UI.
    - Environment variables can override default config (see utils/config.py).
"""

import sys
import os
import logging
from pathlib import Path

# ---------------------------------------------------------------------------
# Ensure project root is on sys.path when running directly
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon

from meta_ia.ui.main_window import MetaIAMainWindow
from meta_ia.core.intelligence import IntelligenceEngine
from meta_ia.utils.logger import setup_logger
from meta_ia.utils.config import Config


def main() -> int:
    """
    Bootstrap and launch the Meta IA desktop application.

    Returns:
        int: Exit code (0 = success, non-zero = error).
    """
    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------
    setup_logger()
    log = logging.getLogger("meta_ia.main")
    log.info("Meta IA v%s starting up…", "1.0.0")

    # ------------------------------------------------------------------
    # Load configuration
    # ------------------------------------------------------------------
    config = Config()
    log.info("Configuration loaded from: %s", config.config_path)

    # ------------------------------------------------------------------
    # PyQt6 Application
    # ------------------------------------------------------------------
    # High-DPI support (Qt6 handles this automatically, but be explicit)
    os.environ.setdefault("QT_AUTO_SCREEN_SCALE_FACTOR", "1")

    app = QApplication(sys.argv)
    app.setApplicationName("Meta IA")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("Meta IA Project")
    app.setOrganizationDomain("meta-ia.local")

    # Set app icon if it exists
    icon_path = PROJECT_ROOT / "assets" / "icon.png"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    # ------------------------------------------------------------------
    # Intelligence Engine (pre-warm before showing UI)
    # ------------------------------------------------------------------
    log.info("Initializing Intelligence Engine…")
    engine = IntelligenceEngine(config=config)
    engine.initialize()
    log.info("Intelligence Engine ready.")

    # ------------------------------------------------------------------
    # Main Window
    # ------------------------------------------------------------------
    window = MetaIAMainWindow(engine=engine, config=config)
    window.show()

    log.info("Meta IA UI launched successfully.")
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
