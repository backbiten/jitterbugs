"""
Meta IA — Meta Intelligence Artificial Program
===============================================
Version: 1.0.0
License: MIT
Description:
    Meta IA is an independent, cross-platform intelligence program built in Python.
    It runs natively on Windows, macOS, and Linux, with mobile support coming
    via Android and iOS. It leverages NumPy for high-performance vector and matrix
    computation, PyQt6 for a modern native UI, and integrates with local AI models
    via Ollama and HuggingFace Transformers.

GitHub: https://github.com/your-org/meta-ia
Copilot: See .github/copilot-instructions.md for AI pair-programming guidelines.
"""

__version__     = "1.0.0"
__author__      = "Meta IA Contributors"
__license__     = "MIT"
__description__ = "Meta Intelligence Artificial — Cross-Platform Desktop AI Program"
