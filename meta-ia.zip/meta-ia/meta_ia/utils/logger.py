"""
meta_ia/utils/logger.py
=======================
Logging configuration for Meta IA.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path


def setup_logger(level: str = "INFO", log_file: str | None = None) -> None:
    """
    Configure the root Meta IA logger.

    Args:
        level:    Log level string ('DEBUG', 'INFO', 'WARNING', 'ERROR').
        log_file: Optional file path; if provided, logs to both file and console.
    """
    numeric_level = getattr(logging, level.upper(), logging.INFO)
    fmt = logging.Formatter(
        fmt="%(asctime)s [%(levelname)-8s] %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger("meta_ia")
    root.setLevel(numeric_level)
    root.handlers.clear()

    # Console handler
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    root.addHandler(ch)

    # Optional file handler
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setFormatter(fmt)
        root.addHandler(fh)
