"""
meta_ia/utils/config.py
=======================
Application configuration for Meta IA.

Loads settings from:
  1. Built-in defaults
  2. ~/.meta_ia/config.json (user override)
  3. Environment variables (META_IA_* prefix)

GitHub Copilot Notes:
    - config.get("section.key", default) is the primary accessor.
    - config.set("section.key", value) writes to user config and persists.
    - All paths are resolved relative to the user's home directory.
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

log = logging.getLogger("meta_ia.utils.config")

CONFIG_DIR  = Path.home() / ".meta_ia"
CONFIG_FILE = CONFIG_DIR  / "config.json"

DEFAULTS: Dict[str, Any] = {
    "app": {
        "name":    "Meta IA",
        "version": "1.0.0",
        "theme":   "dark",
        "language":"en",
    },
    "engine": {
        "top_k":          5,
        "model_backend":  None,   # None = rule engine; "ollama" or "hf" for LLM
        "ollama_model":   "llama3",
        "hf_model":       "gpt2",
    },
    "memory": {
        "max_entries":    2048,
        "auto_save":      True,
        "save_interval":  300,    # seconds
    },
    "ui": {
        "font_size":      13,
        "window_width":   1200,
        "window_height":  800,
        "sidebar_width":  260,
    },
    "logging": {
        "level":  "INFO",
        "file":   str(Path.home() / ".meta_ia" / "meta_ia.log"),
    },
}


def _flatten(d: Dict, prefix: str = "") -> Dict[str, Any]:
    """Flatten nested dict into dotted keys."""
    result: Dict[str, Any] = {}
    for k, v in d.items():
        key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            result.update(_flatten(v, key))
        else:
            result[key] = v
    return result


def _set_nested(d: Dict, key: str, value: Any) -> None:
    """Set a value in a nested dict using a dotted key."""
    parts = key.split(".")
    for part in parts[:-1]:
        d = d.setdefault(part, {})
    d[parts[-1]] = value


def _get_nested(d: Dict, key: str, default: Any = None) -> Any:
    """Get a value from a nested dict using a dotted key."""
    parts = key.split(".")
    for part in parts:
        if not isinstance(d, dict) or part not in d:
            return default
        d = d[part]
    return d


class Config:
    """
    Meta IA Application Configuration.

    Merges built-in defaults with user config file and environment variables.

    Example:
        >>> cfg = Config()
        >>> cfg.get("ui.font_size")     # → 13
        >>> cfg.set("ui.font_size", 15) # → persists to ~/.meta_ia/config.json
    """

    def __init__(self, config_path: Optional[Path] = None) -> None:
        self.config_path = config_path or CONFIG_FILE
        self._data: Dict[str, Any] = {}
        self._load()

    # ------------------------------------------------------------------
    # Load / Save
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """Merge defaults → user file → environment variables."""
        import copy
        self._data = copy.deepcopy(DEFAULTS)

        # User config file
        if self.config_path.exists():
            try:
                with open(self.config_path, "r", encoding="utf-8") as fh:
                    user_cfg = json.load(fh)
                self._deep_merge(self._data, user_cfg)
                log.debug("User config loaded from %s.", self.config_path)
            except Exception as exc:
                log.warning("Could not load user config: %s", exc)

        # Environment variable overrides: META_IA_ENGINE_TOP_K → engine.top_k
        for env_key, env_val in os.environ.items():
            if env_key.startswith("META_IA_"):
                dotted = env_key[8:].lower().replace("_", ".", 1)
                _set_nested(self._data, dotted, env_val)
                log.debug("Config override from env: %s = %r", dotted, env_val)

    def save(self) -> None:
        """Persist current config to the user config file."""
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, "w", encoding="utf-8") as fh:
            json.dump(self._data, fh, indent=2, ensure_ascii=False)
        log.debug("Config saved → %s", self.config_path)

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    def get(self, key: str, default: Any = None) -> Any:
        """Get a config value by dotted key."""
        return _get_nested(self._data, key, default)

    def set(self, key: str, value: Any, persist: bool = True) -> None:
        """Set a config value and optionally persist."""
        _set_nested(self._data, key, value)
        if persist:
            self.save()

    def all(self) -> Dict[str, Any]:
        """Return the full (flattened) config dict."""
        return _flatten(self._data)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _deep_merge(base: Dict, override: Dict) -> None:
        """Recursively merge override into base in-place."""
        for k, v in override.items():
            if k in base and isinstance(base[k], dict) and isinstance(v, dict):
                Config._deep_merge(base[k], v)
            else:
                base[k] = v

    def __repr__(self) -> str:
        return f"Config(path={self.config_path})"
