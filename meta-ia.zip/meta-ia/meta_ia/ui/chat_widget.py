"""
meta_ia/ui/chat_widget.py
=========================
Chat interface widget for Meta IA.

Provides the main user-facing conversation UI:
  - Scrollable message history with user / AI bubbles
  - Async message processing (QThread) to keep UI responsive
  - Typing indicator animation
  - Send on Enter, new-line on Shift+Enter

GitHub Copilot Notes:
    - _WorkerThread processes engine.process() off the main thread.
    - append_message() is the only public method for adding messages.
    - _on_send() is the slot connected to the Send button and Enter key.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Optional

from PyQt6.QtCore    import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui     import QKeyEvent, QFont
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTextEdit,
    QPushButton, QScrollArea, QLabel, QFrame, QSizePolicy,
)

from meta_ia.core.intelligence import IntelligenceEngine
from meta_ia.ui.styles         import COLORS

log = logging.getLogger("meta_ia.ui.chat_widget")


# ---------------------------------------------------------------------------
# Worker thread for non-blocking engine calls
# ---------------------------------------------------------------------------

class _WorkerThread(QThread):
    """Runs IntelligenceEngine.process() in a background thread."""

    response_ready = pyqtSignal(str)
    error_occurred = pyqtSignal(str)

    def __init__(self, engine: IntelligenceEngine, prompt: str, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.prompt = prompt

    def run(self) -> None:
        try:
            response = self.engine.process(self.prompt)
            self.response_ready.emit(response)
        except Exception as exc:
            log.exception("Engine error: %s", exc)
            self.error_occurred.emit(str(exc))


# ---------------------------------------------------------------------------
# Message bubble widget
# ---------------------------------------------------------------------------

class _MessageBubble(QFrame):
    """Single chat message bubble (user or AI)."""

    def __init__(self, role: str, content: str, timestamp: str, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        is_user = (role == "user")

        # Label row
        label_row = QHBoxLayout()
        label_row.setContentsMargins(0, 0, 0, 0)
        name_lbl = QLabel("You" if is_user else "⬡ Meta IA")
        name_lbl.setObjectName("bubble_label")
        time_lbl = QLabel(timestamp)
        time_lbl.setObjectName("bubble_label")
        time_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)

        label_row.addWidget(name_lbl)
        label_row.addStretch()
        label_row.addWidget(time_lbl)

        # Content
        content_lbl = QLabel(content)
        content_lbl.setWordWrap(True)
        content_lbl.setObjectName("user_bubble" if is_user else "ai_bubble")
        content_lbl.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        content_lbl.setFont(QFont("Segoe UI", 13))
        content_lbl.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum
        )

        layout.addLayout(label_row)
        layout.addWidget(content_lbl)

        # Outer alignment
        self.setContentsMargins(
            40 if is_user else 0,
            4,
            0 if is_user else 40,
            4,
        )


# ---------------------------------------------------------------------------
# Typing indicator
# ---------------------------------------------------------------------------

class _TypingIndicator(QLabel):
    """Animated 'Meta IA is thinking…' label."""

    def __init__(self, parent=None):
        super().__init__("⬡ Meta IA is thinking", parent)
        self.setObjectName("bubble_label")
        self._dot_count = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)

    def start(self) -> None:
        self._dot_count = 0
        self._timer.start(400)
        self.show()

    def stop(self) -> None:
        self._timer.stop()
        self.hide()

    def _tick(self) -> None:
        self._dot_count = (self._dot_count + 1) % 4
        self.setText("⬡ Meta IA is thinking" + "." * self._dot_count)


# ---------------------------------------------------------------------------
# Input box (Enter to send, Shift+Enter for newline)
# ---------------------------------------------------------------------------

class _InputBox(QTextEdit):
    """Custom QTextEdit that emits send_requested on Enter."""

    send_requested = pyqtSignal()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if (
            event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter)
            and not (event.modifiers() & Qt.KeyboardModifier.ShiftModifier)
        ):
            self.send_requested.emit()
        else:
            super().keyPressEvent(event)


# ---------------------------------------------------------------------------
# ChatWidget — main widget
# ---------------------------------------------------------------------------

class ChatWidget(QWidget):
    """
    Meta IA Chat Interface.

    Displays conversation history and provides input controls.
    Processes engine calls on a background QThread.

    Signals:
        message_sent(str):      Emitted when user sends a message.
        response_received(str): Emitted when engine returns a response.
    """

    message_sent      = pyqtSignal(str)
    response_received = pyqtSignal(str)

    def __init__(self, engine: IntelligenceEngine, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.engine  = engine
        self._worker: Optional[_WorkerThread] = None
        self._build_ui()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # --- Header ---
        header = QFrame()
        header.setObjectName("header_bar")
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(16, 8, 16, 8)

        title = QLabel("Meta IA Chat")
        title.setObjectName("header_title")
        status = QLabel("● Online")
        status.setObjectName("status_dot")

        h_layout.addWidget(title)
        h_layout.addStretch()
        h_layout.addWidget(status)
        root.addWidget(header)

        # --- Scroll area for messages ---
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setObjectName("chat_area")
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self._messages_widget = QWidget()
        self._messages_widget.setObjectName("chat_area")
        self._messages_layout = QVBoxLayout(self._messages_widget)
        self._messages_layout.setContentsMargins(16, 16, 16, 16)
        self._messages_layout.setSpacing(8)
        self._messages_layout.addStretch()

        self._scroll.setWidget(self._messages_widget)
        root.addWidget(self._scroll, stretch=1)

        # Typing indicator
        self._typing = _TypingIndicator()
        self._typing.hide()
        self._messages_layout.addWidget(self._typing)

        # --- Input area ---
        input_frame = QFrame()
        input_frame.setObjectName("input_frame")
        i_layout = QHBoxLayout(input_frame)
        i_layout.setContentsMargins(12, 12, 12, 12)
        i_layout.setSpacing(10)

        self._input = _InputBox()
        self._input.setObjectName("input_box")
        self._input.setPlaceholderText("Message Meta IA… (Enter to send, Shift+Enter for new line)")
        self._input.setFixedHeight(60)
        self._input.send_requested.connect(self._on_send)

        self._send_btn = QPushButton("Send")
        self._send_btn.setObjectName("send_button")
        self._send_btn.setFixedSize(80, 44)
        self._send_btn.clicked.connect(self._on_send)

        i_layout.addWidget(self._input, stretch=1)
        i_layout.addWidget(self._send_btn)
        root.addWidget(input_frame)

        # Welcome message
        self._add_welcome()

    def _add_welcome(self) -> None:
        welcome = (
            "⬡ Welcome to Meta IA — Meta Intelligence Artificial.\n\n"
            "I am your independent intelligence program. I analyse, reason, "
            "remember, and respond — all running locally on your machine.\n\n"
            "Type anything to begin."
        )
        self.append_message("assistant", welcome)

    # ------------------------------------------------------------------
    # Message handling
    # ------------------------------------------------------------------

    def append_message(self, role: str, content: str) -> None:
        """
        Add a message bubble to the chat.

        Args:
            role:    'user' or 'assistant'
            content: Message text.
        """
        ts = datetime.now().strftime("%H:%M")
        bubble = _MessageBubble(role=role, content=content, timestamp=ts)
        # Insert before the stretch
        self._messages_layout.insertWidget(
            self._messages_layout.count() - 1, bubble
        )
        # Scroll to bottom
        QTimer.singleShot(50, self._scroll_to_bottom)

    def _scroll_to_bottom(self) -> None:
        sb = self._scroll.verticalScrollBar()
        sb.setValue(sb.maximum())

    # ------------------------------------------------------------------
    # Send logic
    # ------------------------------------------------------------------

    def _on_send(self) -> None:
        """Handle send button click / Enter key."""
        prompt = self._input.toPlainText().strip()
        if not prompt or self._worker is not None:
            return

        self._input.clear()
        self._send_btn.setEnabled(False)
        self.append_message("user", prompt)
        self.message_sent.emit(prompt)

        # Show typing indicator
        self._typing.start()
        self._messages_layout.insertWidget(
            self._messages_layout.count() - 1, self._typing
        )
        self._typing.show()

        # Start worker
        self._worker = _WorkerThread(engine=self.engine, prompt=prompt, parent=self)
        self._worker.response_ready.connect(self._on_response)
        self._worker.error_occurred.connect(self._on_error)
        self._worker.finished.connect(self._on_worker_done)
        self._worker.start()

    def _on_response(self, response: str) -> None:
        self._typing.stop()
        self.append_message("assistant", response)
        self.response_received.emit(response)

    def _on_error(self, error: str) -> None:
        self._typing.stop()
        self.append_message(
            "assistant",
            f"⚠ An error occurred:\n{error}\n\nPlease try again.",
        )

    def _on_worker_done(self) -> None:
        self._worker = None
        self._send_btn.setEnabled(True)
        self._input.setFocus()
