"""
meta_ia/ui/dashboard.py
=======================
Dashboard panel showing Meta IA engine statistics.

Displays live stats from IntelligenceEngine.stats() and MemoryStore.stats()
in a card-based grid layout.

GitHub Copilot Notes:
    - Call refresh() to update stats from the engine.
    - Auto-refreshes every 5 seconds via QTimer.
"""

from __future__ import annotations

import logging
from typing import Optional

from PyQt6.QtCore    import Qt, QTimer
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QFrame, QScrollArea, QSizePolicy,
)
from PyQt6.QtGui import QFont

from meta_ia.core.intelligence import IntelligenceEngine

log = logging.getLogger("meta_ia.ui.dashboard")


class _StatCard(QFrame):
    """A single stat display card."""

    def __init__(self, label: str, value: str = "—", parent=None):
        super().__init__(parent)
        self.setObjectName("stat_card")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(6)

        self._value_lbl = QLabel(value)
        self._value_lbl.setObjectName("stat_value")
        self._value_lbl.setFont(QFont("Segoe UI", 24, QFont.Weight.Bold))

        self._label_lbl = QLabel(label.upper())
        self._label_lbl.setObjectName("stat_label")

        layout.addWidget(self._value_lbl)
        layout.addWidget(self._label_lbl)

    def update_value(self, value: str) -> None:
        self._value_lbl.setText(value)


class DashboardWidget(QWidget):
    """
    Meta IA Dashboard.

    Shows engine state, memory statistics, and system health at a glance.
    """

    def __init__(self, engine: IntelligenceEngine, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.engine = engine
        self._cards: dict[str, _StatCard] = {}
        self._build_ui()

        # Auto-refresh every 5 seconds
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh)
        self._timer.start(5000)

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Header
        header = QFrame()
        header.setObjectName("header_bar")
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(16, 8, 16, 8)
        h_lbl = QLabel("Dashboard")
        h_lbl.setObjectName("header_title")
        h_layout.addWidget(h_lbl)
        root.addWidget(header)

        # Scrollable content
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setObjectName("chat_area")

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(24, 24, 24, 24)
        content_layout.setSpacing(24)

        # Section: Engine Status
        content_layout.addWidget(self._section_label("⬡ Intelligence Engine"))
        engine_grid = QGridLayout()
        engine_grid.setSpacing(12)

        self._cards["version"]       = _StatCard("Version",      "—")
        self._cards["status"]        = _StatCard("Status",       "—")
        self._cards["vocab_size"]    = _StatCard("Vocab Size",   "—")
        self._cards["index_shape"]   = _StatCard("Index Shape",  "—")

        engine_grid.addWidget(self._cards["version"],     0, 0)
        engine_grid.addWidget(self._cards["status"],      0, 1)
        engine_grid.addWidget(self._cards["vocab_size"],  0, 2)
        engine_grid.addWidget(self._cards["index_shape"], 0, 3)
        content_layout.addLayout(engine_grid)

        # Section: Memory
        content_layout.addWidget(self._section_label("🧠 Memory Store"))
        memory_grid = QGridLayout()
        memory_grid.setSpacing(12)

        self._cards["entry_count"]  = _StatCard("Entries",      "—")
        self._cards["avg_length"]   = _StatCard("Avg Length",   "—")
        self._cards["max_length"]   = _StatCard("Max Entry",    "—")
        self._cards["user_turns"]   = _StatCard("User Turns",   "—")

        memory_grid.addWidget(self._cards["entry_count"], 0, 0)
        memory_grid.addWidget(self._cards["avg_length"],  0, 1)
        memory_grid.addWidget(self._cards["max_length"],  0, 2)
        memory_grid.addWidget(self._cards["user_turns"],  0, 3)
        content_layout.addLayout(memory_grid)

        content_layout.addStretch()
        scroll.setWidget(content)
        root.addWidget(scroll, stretch=1)

        self.refresh()

    @staticmethod
    def _section_label(text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        return lbl

    def refresh(self) -> None:
        """Pull latest stats from the engine and update cards."""
        try:
            e_stats = self.engine.stats()
            m_stats = self.engine.memory.stats()

            self._cards["version"].update_value(e_stats.get("version", "—"))
            self._cards["status"].update_value("✓ Ready" if e_stats.get("ready") else "⚠ Init")
            self._cards["vocab_size"].update_value(str(e_stats.get("vocab_size", 0)))

            shape = e_stats.get("index_shape", [0, 0])
            self._cards["index_shape"].update_value(f"{shape[0]}×{shape[1]}")

            self._cards["entry_count"].update_value(str(m_stats.get("entry_count", 0)))
            avg = m_stats.get("avg_length", 0.0)
            self._cards["avg_length"].update_value(f"{avg:.0f} ch")
            self._cards["max_length"].update_value(str(m_stats.get("max_length", 0)))

            roles = m_stats.get("roles", {})
            self._cards["user_turns"].update_value(str(roles.get("user", 0)))

        except Exception as exc:
            log.warning("Dashboard refresh error: %s", exc)
