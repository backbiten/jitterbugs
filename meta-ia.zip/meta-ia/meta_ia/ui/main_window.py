"""
meta_ia/ui/main_window.py
=========================
Main application window for Meta IA.

Layout:
  ┌──────────┬────────────────────────────────┐
  │          │                                │
  │ Sidebar  │   Content Area (stacked pages) │
  │          │   • Chat                       │
  │          │   • Dashboard                  │
  │          │   • Settings (stub)            │
  └──────────┴────────────────────────────────┘

GitHub Copilot Notes:
    - _switch_page(index) swaps the active stacked widget page.
    - closeEvent() calls engine.shutdown() for clean persistence.
    - Window geometry is saved/restored via Config.
"""

from __future__ import annotations

import logging
import sys
from typing import Optional

from PyQt6.QtCore    import Qt, QSize, QTimer
from PyQt6.QtGui     import QAction, QCloseEvent, QFont, QIcon
from PyQt6.QtWidgets import (
    QApplication, QFrame, QHBoxLayout, QLabel, QMainWindow,
    QPushButton, QStackedWidget, QStatusBar, QVBoxLayout,
    QWidget, QMenuBar, QMenu, QMessageBox,
)

from meta_ia.core.intelligence import IntelligenceEngine
from meta_ia.ui.chat_widget    import ChatWidget
from meta_ia.ui.dashboard      import DashboardWidget
from meta_ia.ui.styles         import DARK_THEME, COLORS
from meta_ia.utils.config      import Config

log = logging.getLogger("meta_ia.ui.main_window")

NAV_ITEMS = [
    ("💬  Chat",       0),
    ("📊  Dashboard",  1),
    ("⚙️  Settings",   2),
    ("ℹ️  About",      3),
]


class MetaIAMainWindow(QMainWindow):
    """
    Meta IA — Main Application Window.

    Hosts the sidebar navigation and the stacked content area.

    Args:
        engine: Initialized IntelligenceEngine instance.
        config: Application Config instance.
    """

    def __init__(
        self,
        engine: IntelligenceEngine,
        config: Config,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.engine = engine
        self.config = config
        self._nav_buttons: list[QPushButton] = []
        self._setup_window()
        self._build_menu()
        self._build_ui()
        self._apply_theme()
        self._restore_geometry()
        log.info("MetaIAMainWindow constructed.")

    # ------------------------------------------------------------------
    # Window setup
    # ------------------------------------------------------------------

    def _setup_window(self) -> None:
        w = self.config.get("ui.window_width", 1200)
        h = self.config.get("ui.window_height", 800)
        self.setWindowTitle("Meta IA — Meta Intelligence Artificial")
        self.setMinimumSize(QSize(900, 600))
        self.resize(w, h)

    def _apply_theme(self) -> None:
        self.setStyleSheet(DARK_THEME)

    def _restore_geometry(self) -> None:
        """Centre the window on screen if no saved position."""
        screen = QApplication.primaryScreen()
        if screen:
            geo = screen.availableGeometry()
            self.move(
                (geo.width()  - self.width())  // 2,
                (geo.height() - self.height()) // 2,
            )

    # ------------------------------------------------------------------
    # Menu bar
    # ------------------------------------------------------------------

    def _build_menu(self) -> None:
        mb = self.menuBar()

        # File menu
        file_menu = mb.addMenu("File")
        exit_action = QAction("Exit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # View menu
        view_menu = mb.addMenu("View")
        chat_action = QAction("Chat", self)
        chat_action.setShortcut("Ctrl+1")
        chat_action.triggered.connect(lambda: self._switch_page(0))
        dash_action = QAction("Dashboard", self)
        dash_action.setShortcut("Ctrl+2")
        dash_action.triggered.connect(lambda: self._switch_page(1))
        view_menu.addAction(chat_action)
        view_menu.addAction(dash_action)

        # Help menu
        help_menu = mb.addMenu("Help")
        about_action = QAction("About Meta IA", self)
        about_action.triggered.connect(self._show_about)
        help_menu.addAction(about_action)

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Sidebar
        sidebar = self._build_sidebar()
        root.addWidget(sidebar)

        # Stacked content
        self._stack = QStackedWidget()
        self._chat_widget      = ChatWidget(engine=self.engine)
        self._dashboard_widget = DashboardWidget(engine=self.engine)
        self._settings_widget  = self._stub_page("⚙️ Settings", "Settings panel coming soon.")
        self._about_widget     = self._build_about_page()

        self._stack.addWidget(self._chat_widget)
        self._stack.addWidget(self._dashboard_widget)
        self._stack.addWidget(self._settings_widget)
        self._stack.addWidget(self._about_widget)

        root.addWidget(self._stack, stretch=1)

        # Status bar
        self._status_bar = QStatusBar()
        self.setStatusBar(self._status_bar)
        self._status_bar.showMessage("Meta IA — Ready")

        # Connect signals
        self._chat_widget.message_sent.connect(
            lambda msg: self._status_bar.showMessage(f"Processing: {msg[:60]}…")
        )
        self._chat_widget.response_received.connect(
            lambda _: self._status_bar.showMessage("Meta IA — Ready")
        )

    def _build_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(self.config.get("ui.sidebar_width", 260))

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Logo area
        logo_lbl = QLabel("META IA")
        logo_lbl.setObjectName("sidebar_title")
        logo_lbl.setFont(QFont("Segoe UI", 18, QFont.Weight.Bold))

        sub_lbl = QLabel("Meta Intelligence Artificial")
        sub_lbl.setObjectName("sidebar_subtitle")

        layout.addWidget(logo_lbl)
        layout.addWidget(sub_lbl)

        # Separator
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        layout.addWidget(sep)

        # Nav buttons
        for label, page_idx in NAV_ITEMS:
            btn = QPushButton(label)
            btn.setObjectName("nav_button")
            btn.setCheckable(True)
            btn.setChecked(page_idx == 0)
            btn.setFont(QFont("Segoe UI", 13))
            idx = page_idx  # closure capture
            btn.clicked.connect(lambda checked, i=idx: self._switch_page(i))
            layout.addWidget(btn)
            self._nav_buttons.append(btn)

        layout.addStretch()

        # Engine version badge
        ver_lbl = QLabel(f"v{self.engine.VERSION}")
        ver_lbl.setObjectName("sidebar_subtitle")
        ver_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(ver_lbl)

        return sidebar

    def _build_about_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title = QLabel("META IA")
        title.setFont(QFont("Segoe UI", 32, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(f"color: {COLORS['accent']};")

        subtitle = QLabel("Meta Intelligence Artificial")
        subtitle.setFont(QFont("Segoe UI", 14))
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet(f"color: {COLORS['text_secondary']};")

        version = QLabel("Version 1.0.0")
        version.setAlignment(Qt.AlignmentFlag.AlignCenter)
        version.setStyleSheet(f"color: {COLORS['text_muted']};")

        desc = QLabel(
            "Meta IA is an independent, cross-platform intelligence program.\n"
            "Built entirely in Python + NumPy. No external AI cloud dependency.\n"
            "Runs locally on Windows, macOS, and Linux.\n\n"
            "GitHub: https://github.com/your-org/meta-ia"
        )
        desc.setAlignment(Qt.AlignmentFlag.AlignCenter)
        desc.setWordWrap(True)
        desc.setStyleSheet(f"color: {COLORS['text_secondary']}; margin-top: 20px;")

        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addWidget(version)
        layout.addWidget(desc)
        return page

    @staticmethod
    def _stub_page(title: str, message: str) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl = QLabel(f"{title}\n\n{message}")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 14px;")
        layout.addWidget(lbl)
        return page

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def _switch_page(self, index: int) -> None:
        """Switch the stacked widget and update nav button states."""
        self._stack.setCurrentIndex(index)
        for i, btn in enumerate(self._nav_buttons):
            btn.setChecked(i == index)
        log.debug("Switched to page %d.", index)

    # ------------------------------------------------------------------
    # Dialogs
    # ------------------------------------------------------------------

    def _show_about(self) -> None:
        self._switch_page(3)

    # ------------------------------------------------------------------
    # Close event
    # ------------------------------------------------------------------

    def closeEvent(self, event: QCloseEvent) -> None:
        """Save memory and config on close."""
        log.info("Window closing — persisting state…")
        # Save window size
        self.config.set("ui.window_width",  self.width(),  persist=False)
        self.config.set("ui.window_height", self.height(), persist=False)
        self.config.save()
        self.engine.shutdown()
        log.info("Shutdown complete.")
        event.accept()
