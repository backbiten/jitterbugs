"""
meta_ia/ui/__init__.py
"""
from meta_ia.ui.main_window  import MetaIAMainWindow
from meta_ia.ui.chat_widget  import ChatWidget
from meta_ia.ui.dashboard    import DashboardWidget

__all__ = ["MetaIAMainWindow", "ChatWidget", "DashboardWidget"]
