"""
meta_ia/ui/styles.py
====================
Dark-theme stylesheet for the Meta IA PyQt6 UI.

Designed for a sleek, modern intelligence-program aesthetic:
  - Near-black background (#0d0d0d)
  - Electric blue accent (#00aaff)
  - Clean typography (Segoe UI / system-ui)

GitHub Copilot Notes:
    - DARK_THEME is a QSS string; apply via app.setStyleSheet(DARK_THEME).
    - COLORS dict exposes individual colour tokens for use in custom painting.
"""

COLORS = {
    "bg_primary":    "#0d0d0d",
    "bg_secondary":  "#141414",
    "bg_panel":      "#1a1a1a",
    "bg_input":      "#111111",
    "accent":        "#00aaff",
    "accent_hover":  "#0088cc",
    "accent_dim":    "#003d5c",
    "text_primary":  "#e8e8e8",
    "text_secondary":"#888888",
    "text_muted":    "#444444",
    "border":        "#2a2a2a",
    "border_accent": "#00aaff",
    "user_bubble":   "#0d2a3d",
    "ai_bubble":     "#131313",
    "success":       "#00cc88",
    "warning":       "#ffaa00",
    "error":         "#ff4444",
}

DARK_THEME = f"""
/* ============================================================
   Meta IA — Dark Theme Stylesheet
   ============================================================ */

/* Global */
QWidget {{
    background-color: {COLORS["bg_primary"]};
    color: {COLORS["text_primary"]};
    font-family: "Segoe UI", "SF Pro Display", "Ubuntu", "Helvetica Neue", sans-serif;
    font-size: 13px;
    border: none;
    outline: none;
}}

/* Main Window */
QMainWindow {{
    background-color: {COLORS["bg_primary"]};
}}

/* Sidebar */
#sidebar {{
    background-color: {COLORS["bg_secondary"]};
    border-right: 1px solid {COLORS["border"]};
}}

#sidebar_title {{
    font-size: 18px;
    font-weight: 700;
    color: {COLORS["accent"]};
    padding: 16px 12px 4px 12px;
    letter-spacing: 2px;
}}

#sidebar_subtitle {{
    font-size: 10px;
    color: {COLORS["text_secondary"]};
    padding: 0 12px 16px 12px;
    letter-spacing: 1px;
}}

/* Navigation buttons */
QPushButton#nav_button {{
    background-color: transparent;
    color: {COLORS["text_secondary"]};
    border: none;
    border-radius: 6px;
    padding: 10px 14px;
    text-align: left;
    font-size: 13px;
}}
QPushButton#nav_button:hover {{
    background-color: {COLORS["bg_panel"]};
    color: {COLORS["text_primary"]};
}}
QPushButton#nav_button:checked {{
    background-color: {COLORS["accent_dim"]};
    color: {COLORS["accent"]};
    border-left: 3px solid {COLORS["accent"]};
}}

/* Chat area */
#chat_area {{
    background-color: {COLORS["bg_primary"]};
}}

QScrollArea {{
    background-color: {COLORS["bg_primary"]};
    border: none;
}}

QScrollBar:vertical {{
    background: {COLORS["bg_secondary"]};
    width: 6px;
    border-radius: 3px;
}}
QScrollBar::handle:vertical {{
    background: {COLORS["border"]};
    border-radius: 3px;
    min-height: 20px;
}}
QScrollBar::handle:vertical:hover {{
    background: {COLORS["accent"]};
}}
QScrollBar::add-line:vertical,
QScrollBar::sub-line:vertical {{ height: 0; }}

/* Message bubbles */
#user_bubble {{
    background-color: {COLORS["user_bubble"]};
    border: 1px solid {COLORS["accent_dim"]};
    border-radius: 12px;
    padding: 10px 14px;
    color: {COLORS["text_primary"]};
}}

#ai_bubble {{
    background-color: {COLORS["ai_bubble"]};
    border: 1px solid {COLORS["border"]};
    border-radius: 12px;
    padding: 10px 14px;
    color: {COLORS["text_primary"]};
}}

#bubble_label {{
    font-size: 10px;
    color: {COLORS["text_secondary"]};
    margin-bottom: 2px;
}}

/* Input area */
#input_frame {{
    background-color: {COLORS["bg_secondary"]};
    border-top: 1px solid {COLORS["border"]};
    padding: 12px;
}}

QTextEdit#input_box {{
    background-color: {COLORS["bg_input"]};
    color: {COLORS["text_primary"]};
    border: 1px solid {COLORS["border"]};
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 14px;
    selection-background-color: {COLORS["accent_dim"]};
}}
QTextEdit#input_box:focus {{
    border: 1px solid {COLORS["accent"]};
}}

/* Send button */
QPushButton#send_button {{
    background-color: {COLORS["accent"]};
    color: #ffffff;
    border: none;
    border-radius: 8px;
    padding: 10px 20px;
    font-size: 14px;
    font-weight: 600;
    min-width: 80px;
}}
QPushButton#send_button:hover {{
    background-color: {COLORS["accent_hover"]};
}}
QPushButton#send_button:pressed {{
    background-color: {COLORS["accent_dim"]};
}}
QPushButton#send_button:disabled {{
    background-color: {COLORS["text_muted"]};
    color: {COLORS["text_secondary"]};
}}

/* Header bar */
#header_bar {{
    background-color: {COLORS["bg_secondary"]};
    border-bottom: 1px solid {COLORS["border"]};
    padding: 8px 16px;
}}

#header_title {{
    font-size: 15px;
    font-weight: 600;
    color: {COLORS["text_primary"]};
}}

#status_dot {{
    color: {COLORS["success"]};
    font-size: 10px;
}}

/* Dashboard panels */
#stat_card {{
    background-color: {COLORS["bg_panel"]};
    border: 1px solid {COLORS["border"]};
    border-radius: 10px;
    padding: 16px;
}}

#stat_value {{
    font-size: 28px;
    font-weight: 700;
    color: {COLORS["accent"]};
}}

#stat_label {{
    font-size: 11px;
    color: {COLORS["text_secondary"]};
    text-transform: uppercase;
    letter-spacing: 1px;
}}

/* Separator */
QFrame[frameShape="4"],
QFrame[frameShape="5"] {{
    color: {COLORS["border"]};
}}

/* ToolTip */
QToolTip {{
    background-color: {COLORS["bg_panel"]};
    color: {COLORS["text_primary"]};
    border: 1px solid {COLORS["border"]};
    padding: 6px 10px;
    border-radius: 4px;
    font-size: 12px;
}}

/* Status bar */
QStatusBar {{
    background-color: {COLORS["bg_secondary"]};
    color: {COLORS["text_secondary"]};
    font-size: 11px;
    border-top: 1px solid {COLORS["border"]};
}}

/* Menu bar */
QMenuBar {{
    background-color: {COLORS["bg_secondary"]};
    color: {COLORS["text_primary"]};
    border-bottom: 1px solid {COLORS["border"]};
}}
QMenuBar::item:selected {{
    background-color: {COLORS["bg_panel"]};
    color: {COLORS["accent"]};
}}
QMenu {{
    background-color: {COLORS["bg_panel"]};
    color: {COLORS["text_primary"]};
    border: 1px solid {COLORS["border"]};
    border-radius: 6px;
    padding: 4px;
}}
QMenu::item:selected {{
    background-color: {COLORS["accent_dim"]};
    color: {COLORS["accent"]};
    border-radius: 4px;
}}
"""
